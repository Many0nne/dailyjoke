<?php
include "../actions/config.php"; // Assurez-vous d'inclure votre fichier de configuration ici

// Vérification si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération de la blague soumise depuis le formulaire
    $joke = $_POST["joke"];

    // Convertir les caractères accentués en caractères non accentués
    $joke = removeAccents($joke);

    // Récupération de l'adresse IP de l'utilisateur
    $ip = $_SERVER['REMOTE_ADDR'];

    // Vérification si l'adresse IP a déjà soumis une blague le même jour
    $dateAujourdhui = date("Y-m-d");
    $sql = "SELECT * FROM BlaguesSoumises WHERE AdresseIP = ? AND DateSoumission = ?";
    $requete = $connexion->prepare($sql);
    $requete->bind_param("ss", $ip, $dateAujourdhui);
    $requete->execute();
    $resultat = $requete->get_result();

    if ($resultat->num_rows > 0) {
        echo "Vous avez déjà soumis une blague aujourd'hui, revenez demain.";
    } else {
        // Insertion de la blague dans la table "Blagues"
        $sql = "INSERT INTO Blagues (Contenu) VALUES (?)";
        $requete = $connexion->prepare($sql);
        $requete->bind_param("s", $joke);

        if ($requete->execute()) {
            echo "La blague a été ajoutée avec succès.";

            // Enregistrement de l'adresse IP et de la date de soumission
            $sql = "INSERT INTO BlaguesSoumises (AdresseIP, DateSoumission) VALUES (?, ?)";
            $requete = $connexion->prepare($sql);
            $requete->bind_param("ss", $ip, $dateAujourdhui);
            $requete->execute();
        } else {
            echo "Erreur lors de l'ajout de la blague : " . $requete->error;
        }
    }

    // Fermeture de la connexion à la base de données
    $connexion->close();
}

// Fonction pour retirer les accents
function removeAccents($str) {
    $accentedChars = ['À'=>'A','Á'=>'A','Â'=>'A','Ã'=>'A','Ä'=>'A','Å'=>'A','à'=>'a','á'=>'a','â'=>'a','ã'=>'a','ä'=>'a','å'=>'a','Ç'=>'C','ç'=>'c','È'=>'E','É'=>'E','Ê'=>'E','Ë'=>'E','è'=>'e','é'=>'e','ê'=>'e','ë'=>'e','Ì'=>'I','Í'=>'I','Î'=>'I','Ï'=>'I','ì'=>'i','í'=>'i','î'=>'i','ï'=>'i','Ñ'=>'N','ñ'=>'n','Ò'=>'O','Ó'=>'O','Ô'=>'O','Õ'=>'O','Ö'=>'O','Ø'=>'O','ò'=>'o','ó'=>'o','ô'=>'o','õ'=>'o','ö'=>'o','ø'=>'o','Ù'=>'U','Ú'=>'U','Û'=>'U','Ü'=>'U','ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u','Ý'=>'Y','ý'=>'y'];

    // Utilisez str_replace avec le tableau associatif pour effectuer les remplacements
    $str = str_replace(array_keys($accentedChars), array_values($accentedChars), $str);

    return $str;
}
?>



?>
