<?php
include "./actions/config.php";

// Définir une variable pour la nouvelle blague (par défaut, vide)
$newJoke = "";

// Fonction pour choisir une nouvelle blague aléatoirement et mettre à jour le cookie
function chooseRandomJokeAndUpdateCookie($connexion) {
    $sql = "SELECT * FROM Blagues ORDER BY RAND() LIMIT 1";
    $resultat = $connexion->query($sql);

    if ($resultat->num_rows > 0) {
        // Récupérer la nouvelle blague au hasard
        $blague = $resultat->fetch_assoc();

        // Mettre à jour la blague dans le cookie
        setcookie('last_joke', $blague["Contenu"], strtotime('tomorrow midnight')); // Expire à minuit

        // Mettre à jour la variable $newJoke avec la nouvelle blague
        global $newJoke;
        $newJoke = $blague["Contenu"];
    }
}

// Vérification si un cookie "last_joke" existe
if (!isset($_COOKIE['last_joke'])) {
    // Si le cookie n'existe pas, choisissez une nouvelle blague aléatoirement et mettez à jour le cookie
    chooseRandomJokeAndUpdateCookie($connexion);
} else {
    // Si le cookie existe, vous pouvez quand même choisir une nouvelle blague aléatoirement
    chooseRandomJokeAndUpdateCookie($connexion);
}

// Récupérer la blague du cookie
$lastJoke = isset($_COOKIE['last_joke']) ? $_COOKIE['last_joke'] : "";
?>