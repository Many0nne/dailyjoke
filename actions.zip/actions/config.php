<?php


// Paramètres de connexion à la base de données
$serveur = 'localhost'; // Adresse du serveur MySQL
$utilisateur = 'root'; // Identifiant de connexion
$motDePasse = ''; // Mot de passe (laissez vide car vous avez indiqué aucun mot de passe)
$baseDeDonnees = 'daily_joke'; // Nom de la base de données

// Tentative de connexion à la base de données
$connexion = new mysqli($serveur, $utilisateur, $motDePasse, $baseDeDonnees);

// Vérification de la connexion
if ($connexion->connect_error) {
    die("Échec de la connexion à la base de données : " . $connexion->connect_error);
}


?>